window.addEventListener('onready', function () {

});